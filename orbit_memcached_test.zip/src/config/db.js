var Memcached = require('memcached');
require('dotenv').config()


// Created object for memcached
const memcached = new Memcached();
/* code to connect with your memecahced server */
memcached.connect(process.env.MEMCACHED_HOST + ":" + process.env.MEMCACHED_PORT, function (err, conn) {
    if (err) {
        console.log(conn.server, 'error while memcached connection!!', err);
    }else console.log('connection establish success from', conn.serverAddress);
    
});

module.exports = memcached;