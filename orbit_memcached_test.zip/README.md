# orbit_memcached_test

# Steps to run the project
1.  npm install
2.  npm start


# Once start the server you can see the message in console for both node and memcached
    Server running on port 8080
    connection establish success from localhost:11211

# once you saw this message you can directly hit this api 'http://localhost:8080 or wait for few seconds for output it will execute the scheduler after few seconds